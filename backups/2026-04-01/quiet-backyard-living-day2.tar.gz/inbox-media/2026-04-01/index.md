# Inbox Media — 2026-04-01

Photos Jeff shared through Telegram on 2026-04-01.

## wildlife
- `wildlife/squirrel-chipmunk-feeder-chaos.jpg` — Squirrel on the feeder with chipmunk below; lively backyard feeder scene.
- `wildlife/hummingbird-feeder-glow.jpg` — Hummingbird at feeder with strong light and color; excellent candidate for website and Pinterest use.

## garden
- `garden/grapes-on-vine.jpg` — Healthy grapes on the vine; strong fit for useful, calm backyard/garden content.

## Website use notes
- Strong website candidate: `wildlife/hummingbird-feeder-glow.jpg`
- Strong website candidate: `garden/grapes-on-vine.jpg`
- Fun wildlife/social candidate: `wildlife/squirrel-chipmunk-feeder-chaos.jpg`
